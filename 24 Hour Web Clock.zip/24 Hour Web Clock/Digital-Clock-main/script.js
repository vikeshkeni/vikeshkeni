function Time() {

  // Creating object of the Date class
  var date = new Date();

  // Get current hour
  var hour = date.getHours();
  // Get current minute
  var minute = date.getMinutes();
  // Get current second
  var second = date.getSeconds();

  // Variable to store AM / PM
  var period = "";

  const convertTime12to24 = time12h => {
    const [time, modifier] = time12h.split(" ");
  
    let [hours, minutes] = time.split(":");
  
    if (hours === "12") {
      hours = "00";
    }
  
    if (modifier === "PM") {
      hours = parseInt(hours, 10) + 12;
    }
  
    return `${hours}:${minutes}`;
  };
  
  var convertedTime = convertTime12to24("01:00 PM");
  console.log(convertedTime);
  // Output: 13:00

  // Updating hour, minute, and second
  // if they are less than 10
  hour = update(hour);
  minute = update(minute);
  second = update(second);

  // Adding time elements to the div
  document.getElementById("digital-clock").innerText = hour + " : " + minute + " : " + second + " " + period;

  // Set Timer to 1 sec (1000 ms)
  setTimeout(Time, 1000);
}

// Function to update time elements if they are less than 10
// Append 0 before time elements if they are less than 10
function update(t) {
  if (t < 10) {
    return "0" + t;
  }
  else {
    return t;
  }
}

Time();
